#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Qhull::qhull" for configuration ""
set_property(TARGET Qhull::qhull APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(Qhull::qhull PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/bin/qhull.js"
  )

list(APPEND _cmake_import_check_targets Qhull::qhull )
list(APPEND _cmake_import_check_files_for_Qhull::qhull "${_IMPORT_PREFIX}/bin/qhull.js" )

# Import target "Qhull::rbox" for configuration ""
set_property(TARGET Qhull::rbox APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(Qhull::rbox PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/bin/rbox.js"
  )

list(APPEND _cmake_import_check_targets Qhull::rbox )
list(APPEND _cmake_import_check_files_for_Qhull::rbox "${_IMPORT_PREFIX}/bin/rbox.js" )

# Import target "Qhull::qconvex" for configuration ""
set_property(TARGET Qhull::qconvex APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(Qhull::qconvex PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/bin/qconvex.js"
  )

list(APPEND _cmake_import_check_targets Qhull::qconvex )
list(APPEND _cmake_import_check_files_for_Qhull::qconvex "${_IMPORT_PREFIX}/bin/qconvex.js" )

# Import target "Qhull::qdelaunay" for configuration ""
set_property(TARGET Qhull::qdelaunay APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(Qhull::qdelaunay PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/bin/qdelaunay.js"
  )

list(APPEND _cmake_import_check_targets Qhull::qdelaunay )
list(APPEND _cmake_import_check_files_for_Qhull::qdelaunay "${_IMPORT_PREFIX}/bin/qdelaunay.js" )

# Import target "Qhull::qvoronoi" for configuration ""
set_property(TARGET Qhull::qvoronoi APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(Qhull::qvoronoi PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/bin/qvoronoi.js"
  )

list(APPEND _cmake_import_check_targets Qhull::qvoronoi )
list(APPEND _cmake_import_check_files_for_Qhull::qvoronoi "${_IMPORT_PREFIX}/bin/qvoronoi.js" )

# Import target "Qhull::qhalf" for configuration ""
set_property(TARGET Qhull::qhalf APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(Qhull::qhalf PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/bin/qhalf.js"
  )

list(APPEND _cmake_import_check_targets Qhull::qhalf )
list(APPEND _cmake_import_check_files_for_Qhull::qhalf "${_IMPORT_PREFIX}/bin/qhalf.js" )

# Import target "Qhull::qhull_r" for configuration ""
set_property(TARGET Qhull::qhull_r APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(Qhull::qhull_r PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NOCONFIG "C"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libqhull_r.a"
  )

list(APPEND _cmake_import_check_targets Qhull::qhull_r )
list(APPEND _cmake_import_check_files_for_Qhull::qhull_r "${_IMPORT_PREFIX}/lib/libqhull_r.a" )

# Import target "Qhull::qhullcpp" for configuration ""
set_property(TARGET Qhull::qhullcpp APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(Qhull::qhullcpp PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NOCONFIG "CXX"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libqhullcpp.a"
  )

list(APPEND _cmake_import_check_targets Qhull::qhullcpp )
list(APPEND _cmake_import_check_files_for_Qhull::qhullcpp "${_IMPORT_PREFIX}/lib/libqhullcpp.a" )

# Import target "Qhull::qhullstatic" for configuration ""
set_property(TARGET Qhull::qhullstatic APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(Qhull::qhullstatic PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NOCONFIG "C"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libqhullstatic.a"
  )

list(APPEND _cmake_import_check_targets Qhull::qhullstatic )
list(APPEND _cmake_import_check_files_for_Qhull::qhullstatic "${_IMPORT_PREFIX}/lib/libqhullstatic.a" )

# Import target "Qhull::qhullstatic_r" for configuration ""
set_property(TARGET Qhull::qhullstatic_r APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(Qhull::qhullstatic_r PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NOCONFIG "C"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libqhullstatic_r.a"
  )

list(APPEND _cmake_import_check_targets Qhull::qhullstatic_r )
list(APPEND _cmake_import_check_files_for_Qhull::qhullstatic_r "${_IMPORT_PREFIX}/lib/libqhullstatic_r.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
